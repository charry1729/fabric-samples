const express = require('express');

const router = express.Router();

const read_file = require('../controllers/notarycontroller');

// router.get('/all', read_file.get_data); // readAllCompany

router.get('/:id', read_file.get_id_data); //readnotary
// router.delete('/:id', read_file.delete_id_data); // deletenotary
// // router.post('/', read_file.load_data5);
// router.post('/cert', read_file.update_cert_data); // updatenotarycert
// router.post('/partner', read_file.update_part_data); // updatenotarypartner

// router.get('/partner/:id', read_file.get_part_data); // readnotarybyPartner

module.exports = router;
